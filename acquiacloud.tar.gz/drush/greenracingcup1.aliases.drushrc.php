<?php

if (!isset($drush_major_version)) {
  $drush_version_components = explode('.', DRUSH_VERSION);
  $drush_major_version = $drush_version_components[0];
}
// Site greenracingcup1, environment dev
$aliases['dev'] = array(
  'root' => '/var/www/html/greenracingcup1.dev/docroot',
  'ac-site' => 'greenracingcup1',
  'ac-env' => 'dev',
  'ac-realm' => 'devcloud',
  'uri' => 'greenracingcup1m396oq4syg.devcloud.acquia-sites.com',
  'remote-host' => 'free-4011.devcloud.hosting.acquia.com',
  'remote-user' => 'greenracingcup1.dev',
  'path-aliases' => array(
    '%drush-script' => 'drush' . $drush_major_version,
  )
);
$aliases['dev.livedev'] = array(
  'parent' => '@greenracingcup1.dev',
  'root' => '/mnt/gfs/greenracingcup1.dev/livedev/docroot',
);

if (!isset($drush_major_version)) {
  $drush_version_components = explode('.', DRUSH_VERSION);
  $drush_major_version = $drush_version_components[0];
}
// Site greenracingcup1, environment test
$aliases['test'] = array(
  'root' => '/var/www/html/greenracingcup1.test/docroot',
  'ac-site' => 'greenracingcup1',
  'ac-env' => 'test',
  'ac-realm' => 'devcloud',
  'uri' => 'greenracingcup1zfdor9kqus.devcloud.acquia-sites.com',
  'remote-host' => 'free-4011.devcloud.hosting.acquia.com',
  'remote-user' => 'greenracingcup1.test',
  'path-aliases' => array(
    '%drush-script' => 'drush' . $drush_major_version,
  )
);
$aliases['test.livedev'] = array(
  'parent' => '@greenracingcup1.test',
  'root' => '/mnt/gfs/greenracingcup1.test/livedev/docroot',
);
